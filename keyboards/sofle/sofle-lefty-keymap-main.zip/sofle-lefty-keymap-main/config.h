#pragma once

#include "config_common.h"
#define SPLIT_USB_DETECT
#define MASTER_RIGHT

